/*jslint node: true */
'use strict';

var mashery = require('./lib/mashery');

// initialize the API client
var apiClient = mashery.init({
    user: 'rkiesler12',
    pass: 'Mashery*4321',
    key: 'yjdg8w6grxd2ybe79nwx44n5',
    secret: 'N4pHpESkGd',
    areaUuid: '59fbc02b-7025-41b3-b5b0-9ded0c5929d7'
});

// note authentication will be automatically handled for you

// list all services
apiClient.methods.fetchAllServices({}, function(serviceData, serviceRawResponse){
    console.log(JSON.stringify(serviceData, null, 4));
});
